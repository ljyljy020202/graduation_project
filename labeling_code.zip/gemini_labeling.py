import os
import json
from google import genai

client = genai.Client(api_key="AIzaSyA9LiIaH7BChIpv43rAfIJN-e_yyhy2ZeU")

# ✅ 라벨링용 프롬프트 (system 메시지)
SYSTEM_PROMPT = """
[SYSTEM]
당신은 보이스피싱 탐지 전문 인공지능이다.  
당신의 임무는 주어진 통화 대화문을 문장 단위로 분석하여,  
각 문장이 보이스피싱(사기)일 가능성이 있는지 판단하는 것이다.

각 문장에 대해 다음과 같이 라벨을 지정한다:
- 1: 보이스피싱 또는 사기성 발언으로 의심되는 문장
- 0: 정상적인 문장

문장의 사기성을 판단할 때는 발화자의 명칭(예:사기범)은 고려하지 않고, 오직 발화 내용만 고려한다.

[INPUT FORMAT]
1. 여러 개의 문장으로 구성된 대화 스크립트가 입력으로 주어진다.
2. 입력의 각 줄이 하나의 문장이며, 각 줄은 'speaker : content'와 같은 형식으로 구성된다.
3. 입력 예시는 아래와 같다.
사기범 : 안녕하세요, 은행 고객센터입니다.  
피해자 : 네, 무슨 일이신가요?  
사기범 : 고객님의 계좌에서 이상 거래가 감지되었습니다.  
피해자 : 어떤 거래요?  
사기범 : 신속히 본인 확인을 위해 계좌번호와 비밀번호를 말씀해 주세요.  
피해자 : 네, 알겠습니다.

[OUTPUT FORMAT]
1. 출력은 JSON 배열 하나만 반환한다.
2. 배열의 각 원소(객체)는 아래 4개 필드를 모두 포함한다.
    - `idx`: 정수, 입력과 동일한 인덱스
    - `label`: 정수 0 또는 1 (판정 결과)
    - `speaker`: 문자열(화자 표기가 없으면 `null`)
    - `text`: 문자열, 원문 발화(개인정보 마스킹 토큰은 그대로 유지)
3. 객체의 순서는 입력 인덱스 오름차순을 따른다.
4. 출력은 사람이 읽기 쉬운 포맷으로 줄바꿈과 들여쓰기가 적용된 형태로 반환한다.
    - 각 객체는 새로운 줄에서 시작하며, JSON 표준 들여쓰기(2칸 이상)를 사용한다.
    - 예: 아래와 같이 `[`로 시작하고 `]`로 끝나며 각 객체가 줄바꿈되어 구분된다.
5. JSON 배열 외의 부가 텍스트, 주석, 코드블록 표기 금지.
6. 정확성 체크(반드시 만족):
    - 배열 길이 = 입력 발화 수와 동일.
    - 각 객체의 `idx`는 입력의 인덱스를 그대로 사용하고 중복 없음.
    - `label`은 0 또는 1의 정수만 허용.
    - `speaker`는 화자 미기재 시 `null`, 있으면 문자열.
    - `text`는 원문을 그대로 사용하며, 따옴표/역슬래시는 표준 JSON 이스케이프를 적용한다(마스킹 토큰은 원형 유지).
"""

# ✅ 입력/출력 폴더 설정
input_folder = "./Simple_DataSet"
output_folder = "./results_gemini"

os.makedirs(output_folder, exist_ok=True)

# ✅ 모든 하위 폴더 탐색
for root, dirs, files in os.walk(input_folder):
    for file in files:
        if not file.endswith(".txt"):
            continue

        input_path = os.path.join(root, file)

        # ✅ results 폴더에 동일한 구조로 출력 폴더 생성
        relative_path = os.path.relpath(root, input_folder)
        output_dir = os.path.join(output_folder, relative_path)
        os.makedirs(output_dir, exist_ok=True)

        output_path = os.path.join(output_dir, file.replace(".txt", ".json"))

        print(f"🔍 Processing: {input_path}")

        # ✅ 파일 내용 읽기
        with open(input_path, "r", encoding="utf-8") as f:
            conversation = f.read().strip()

        try:
            # ✅ Gemini API 요청
            response = client.models.generate_content(
                model="gemini-2.5-pro",
                contents=f"{SYSTEM_PROMPT}\n\n대화 내용:\n{conversation}"
            )

            content = response.text.strip()

            # ✅ JSON 코드블록 제거 (```json ... ``` 형태 대응)
            if content.startswith("```"):
                # 코드블록 시작과 끝을 제거
                content = content.strip("`")
                # 'json'이라는 언어 표기 제거
                content = content.replace("json", "", 1).strip()
                # 만약 여전히 ``` 가 남아 있으면 제거
                content = content.replace("```", "").strip()

            # ✅ JSON 파싱 시도
            try:
                result_json = json.loads(content)
            except json.JSONDecodeError:
                print(f"⚠️ JSON 파싱 실패: {file}")
                result_json = {"raw_response": content}

            # ✅ 결과 저장
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(result_json, f, ensure_ascii=False, indent=2)

            print(f"✅ Saved: {output_path}")

        except Exception as e:
            print(f"❌ Error processing {file}: {e}")